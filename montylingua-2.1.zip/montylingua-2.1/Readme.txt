By downloading and using MontyLingua, you agree to the terms 
given in License.txt and MontyLingua.html

Documentation for Python is located in MontyLingua.html
Documentation for Java is located in JMontyLingua.html
