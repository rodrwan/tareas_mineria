
class MontySettings:
    JYTHON_P=0 